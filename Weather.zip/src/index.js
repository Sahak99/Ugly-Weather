import React from 'react';
import ReactDOM from 'react-dom';
import Page from './components/common/Page';

import './index.css';

const App = () => {
    return (
        <div className='App'>
            <Page />
        </div>
    )   
}

ReactDOM.render(
    <App />,
    document.getElementById('root')
)