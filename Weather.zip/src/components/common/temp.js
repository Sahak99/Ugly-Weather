getWeather = async (event) => {
    event.preventDefault();
    const city = this.state.city;
    const API = await fetch(`${API_URL}${city}${key}&units=${this.state.unit}`);
    const data = await API.json();
    this.setState(this.state = {
        temperature: data.main.temp,
        weather: data.weather[0].main,
        wind: data.wind.speed    
    })
    console.log(this.state);
    if(city) {
        this.setState(this.state = {
        found: true,
        })
    }
}
