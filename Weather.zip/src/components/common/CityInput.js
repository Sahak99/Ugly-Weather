import React from 'react';

const CityInput = (props) => {
    const { getWeather, handleCity, handleUnit } = props;
    return (
        <form onSubmit={getWeather}>
            <select onChange={handleUnit} >
            <option value='c'>C°</option>
            <option value='f'>F°</option>
            </select>
            <input onChange={handleCity} />
            <button>Enter</button>
        </form>
    )
}

export default CityInput;   