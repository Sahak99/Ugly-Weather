import React from 'react';
import './Header.css';

const Header = () => {
    return (
        <header className='Header'>
            Welcome! Please enter a city name
        </ header>
    )
}   

export default Header;