import React, { Component } from 'react';
import Header from './Header'
import CityImput from './CityInput';
import { API_URL, key } from '../../Config';
import About from './About';
import Info from './Info';
import Loading from './Loading';
import './Page.css';

class Page extends Component {
    constructor() {
        super();
        this.state = {
            unit:'metric',
            city: null,
            temperature: 0,
            weather: null,
            wind: 0,
            found: false,
            load:false,
            error:false
        }
    }

    getWeather = (event) => {
        event.preventDefault();
        this.setState(this.state = {
            load:true
        },()=>this.fetchWeather());
    }



fetchWeather = () => {
    const city = this.state.city;
        if(city){
        const API = fetch(`${API_URL}${city}${key}&units=${this.state.unit}`)
        .then(resp => {if(resp.ok){return resp.json()}else {this.setState(this.state = {load:false,error:true});return Promise.reject(resp)}})
        .then(data => {
            this.setState(this.state = {
            temperature: data.main.temp,
            weather: data.weather[0].main,
            wind: data.wind.speed,
            load:false,
            error:false    
        })
    })
}
        if(city) {
            this.setState(this.state = {
            found: true,
            }) 
        } else {this.setState(this.state = {
            load: false,
            })}
}

    
    handleCity = (event) => {
        let value = event.target.value;
        this.setState(this.state = {
            city: value
        })
    }

    handleUnit = ( data ) => {
        let unit = data.target.value;
        if(unit=='f') unit='imperial';
        else unit='metric';
        this.setState( this.state = {
            unit: unit,
            load:true
            },()=>{this.fetchWeather()})
    }
    
    render (){
        return (
            <div className='Page'>
                <Header />  
                <CityImput 
                   getWeather={this.getWeather}
                   handleCity={this.handleCity}
                   handleUnit={this.handleUnit}
                />
                
                {this.state.found &&  
                <Info 
                    temperature={this.state.temperature}
                    weather={this.state.weather}
                    wind={this.state.wind}
                    error={this.state.error}
                />}
                <About />
                {this.state.load && <Loading />}
            </div>
        )
    }
}
export default Page;
