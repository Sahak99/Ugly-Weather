import React from 'react';

const Info = (props) => {
    const { temperature, weather, wind, error } = props;
    if(!error) {return(
        <div>
            <br />
            Temperature: {temperature} <br />
            Weather: {weather} <br />
            Wind: {wind} <br />
            <br />
        </div>
        
    )} else return (
        <div>
            Sorry, couldn't find that city
        </div>
    )
}

export default Info;