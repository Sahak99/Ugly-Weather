import React from 'react';
import propTypes from 'prop-types';
import './Loading.css';


const Loading = (props) => {
    const { width, height } = props;
    return (
        <div 
        className='Loading'
        style= {{
            width,
            height
        }}
        >

        </div>
    )
}
Loading.propTypes = {
    width: propTypes.string,
    height: propTypes.string
}
Loading.defaultProps = {
    width:'16px',
    height:'16px'
}
export default Loading;