
export const API_URL = "http://api.openweathermap.org/data/2.5/weather?q=";
export const  key = ",&appid=914182bc794bed7a69bc19239db4e50a";
